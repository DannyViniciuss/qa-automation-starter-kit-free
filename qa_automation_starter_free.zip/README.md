# QA Automation Starter Kit (Free Demo)

This is a **free demo** of the QA Automation Starter Kit using **Cypress + TypeScript**.

## Features
- 1 simple test: `login.cy.ts`
- Shows how to test invalid login on a demo page.

## How to Install
1. Make sure you have **Node.js** installed (https://nodejs.org).
2. Create a new project folder and run:
   ```bash
   npm init -y
   npm install cypress typescript ts-node @cypress/webpack-preprocessor --save-dev
   ```
3. Copy the `cypress/` folder into your project.
4. Open Cypress:
   ```bash
   npx cypress open
   ```

## Run the Test
- In the Cypress UI, select `login.cy.ts` under **E2E Testing**.
- The test will open a browser and try an invalid login.

---
This is only a **demo version**. The full kit includes:
- Login + Form Validation + Search + API + Screenshot on Failure.
- Complete PDF guide.
