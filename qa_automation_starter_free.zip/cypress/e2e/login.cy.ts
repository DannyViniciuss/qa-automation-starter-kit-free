
// cypress/e2e/login.cy.ts
describe('Login Test', () => {
  it('should display error on invalid login', () => {
    cy.visit('https://example.com/login');
    cy.get('input[name="username"]').type('wronguser');
    cy.get('input[name="password"]').type('wrongpassword');
    cy.get('button[type="submit"]').click();
    cy.contains('Invalid username or password').should('be.visible');
  });
});
